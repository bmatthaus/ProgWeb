<?php
namespace frontend\models;

use yii\base\Model;
use common\models\User;

/**
 * Signup form
 */
class SignupForm extends Model
{
    public $username;
    public $email;
    public $password;
    public $password2;
    public $id_curso;
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            ['username', 'trim'],
            ['username', 'required','message'=>'Este campo é obrigatório!'],
            ['username', 'unique', 'targetClass' => '\common\models\User', 'message' => 'Este nome já está em uso.'],
            ['username', 'string', 'min' => 2, 'max' => 255],

            ['email', 'trim'],
            ['email', 'required','message'=>'Este campo é obrigatório!'],
            ['email', 'email','message'=>'Este email é inválido!'],
            ['email', 'string', 'max' => 255],
            ['email', 'unique', 'targetClass' => '\common\models\User', 'message' => 'Este e-mail já está em uso.'],

            ['password', 'required','message'=>'Este campo é obrigatório!'],
            ['password', 'string', 'min' => 6],

 
            ['password2', 'required','message'=>'Este campo é obrigatório!'],
            ['password2', 'string', 'min' => 6],
            ['password2', 'compare','compareAttribute'=>'password','message'=>'As senhas não são iguais!'],

	    ['id_curso', 'trim'],

        ];
    }


    /**
     * Signs user up.
     *
     * @return User|null the saved model or null if saving fails
     */
   public function attributeLabels()
   {
        return [
            'username' => 'Nome',
            'email' => 'Endereço de E-Mail',
            'password' => 'Senha',
	    'password2' => 'Confirme a Senha',
            'id_curso' => 'Curso de Graduação',
        ];
    }


    public function signup()
    {
        if (!$this->validate()) {
            return null;
        }
        
        $user = new User();
        $user->username = $this->username;
        $user->email = $this->email;
        $user->setPassword($this->password);
        $user->generateAuthKey();
        $user->id_curso = $this->id_curso;
        return $user->save() ? $user : null;
    }
}
