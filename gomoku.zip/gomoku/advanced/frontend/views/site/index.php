<?php

/* @var $this yii\web\View */
use yii\helpers\Html;
use common\models\Partida;

$this->title = 'Gomoku Game!';
?>
<div class="site-index">

    <div class="jumbotron" style="padding-top:0px;padding-bottom:0px">
        <h2>Gomoku Game!</h2>

        <?= Html::img('gomoku.png',['style'=>'width:100px']) ?>

        <p class="lead">Jogo clássico para dois jogadores, onde um após o outro marca cruzes e quadrados num quadro com treze casas horizontais e treze verticais.</p>

        <?php if(!Yii::$app->user->isGuest): ?>
        <p><?= Html::a('Iniciar Nova Partida',['partida/create'],['class'=>'btn btn-lg btn-success'])?></p>
   

    	<?php endif; ?>


    </div>

</div>
